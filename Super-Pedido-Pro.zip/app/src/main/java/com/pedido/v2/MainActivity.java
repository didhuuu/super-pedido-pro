package com.pedido.v2;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidFileBridge(), "AndroidFileBridge");
        webView.loadUrl("file:///android_asset/app/index.html");

        setContentView(webView);
    }

    public class AndroidFileBridge {
        @JavascriptInterface
        public void sharePdf(String filename, String base64) {
            try {
                if (base64 == null || base64.trim().isEmpty()) {
                    throw new Exception("PDF vazio");
                }

                String clean = base64;
                int comma = clean.indexOf(',');
                if (comma >= 0) clean = clean.substring(comma + 1);

                byte[] bytes = Base64.decode(clean, Base64.DEFAULT);

                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists() && !dir.mkdirs()) {
                    throw new Exception("Não foi possível criar a pasta temporária");
                }

                String safeName = (filename == null || filename.trim().isEmpty())
                        ? "pedido.pdf" : filename;
                File file = new File(dir, safeName);

                try (FileOutputStream out = new FileOutputStream(file)) {
                    out.write(bytes);
                    out.flush();
                }

                Uri uri = FileProvider.getUriForFile(
                        MainActivity.this,
                        getPackageName() + ".fileprovider",
                        file
                );

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("application/pdf");
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(intent, "Enviar PDF"));
            } catch (Exception e) {
                Toast.makeText(
                        MainActivity.this,
                        "Erro ao compartilhar PDF: " + e.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }

        @JavascriptInterface
        public void saveBase64(String filename, String base64) {
            try {
                if (base64 == null || base64.trim().isEmpty()) throw new Exception("Arquivo vazio");
                String clean = base64;
                int comma = clean.indexOf(',');
                if (comma >= 0) clean = clean.substring(comma + 1);
                byte[] bytes = Base64.decode(clean, Base64.DEFAULT);
                File dir = new File(getFilesDir(), "exports");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("Não foi possível criar a pasta");
                String safeName = (filename == null || filename.trim().isEmpty()) ? "arquivo.bin" : new File(filename).getName();
                File file = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                Toast.makeText(MainActivity.this, "Arquivo salvo: " + safeName, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Erro ao salvar arquivo: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }

        @JavascriptInterface
        public void shareText(String text) {
            try {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(intent, "Enviar pedido"));
            } catch (Exception e) {
                Toast.makeText(
                        MainActivity.this,
                        "Erro ao compartilhar pedido: " + e.getMessage(),
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
