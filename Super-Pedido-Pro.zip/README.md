# Pedido V2

Aplicativo Android do Super Pedido, baseado na versão HTML testada.

## Nome do aplicativo
Pedido V2

## Conteúdo
- HTML funcional validado
- Importação XLSX/CSV
- Pedido e estoque
- Geração e compartilhamento de PDF
- Envio via WhatsApp pelo compartilhamento do Android
- Zeragem de estoque e pedido após envio
- Ícone Pedido V2

## Gerar APK
O workflow `.github/workflows/build.yml` gera automaticamente o APK Debug no GitHub Actions.
